--
-- PostgreSQL database cluster dump
--

\restrict Qfk9ElCA0fmKnlaqdvwEzk5hg6HmG1oldzD4kPtZSnB6Lc3DiuungGbLA3UMWtu

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE flowcase;
ALTER ROLE flowcase WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:z3CJ97G0dWK7CFApKw/NVg==$0S22F537rSLFI6ectBj+G5G5B/M30HISxrmBQCL0RSo=:mMyHKn6Ii1zIWBQ7AItfTttu43DewsTVfVCRubESc08=';

--
-- User Configurations
--








\unrestrict Qfk9ElCA0fmKnlaqdvwEzk5hg6HmG1oldzD4kPtZSnB6Lc3DiuungGbLA3UMWtu

--
-- PostgreSQL database cluster dump complete
--

