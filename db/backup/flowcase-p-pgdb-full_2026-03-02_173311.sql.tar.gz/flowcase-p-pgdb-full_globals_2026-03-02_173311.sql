--
-- PostgreSQL database cluster dump
--

\restrict 6lYML2hH8NexFCid87JrJFxdjiyzfIm6XqmvDRTYP8mVadrwXSbIkk8CieVpGPe

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE flowcase;
ALTER ROLE flowcase WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:NxLImXJWiCENFjdAh3LysA==$+zB/AP5JcFG6NjPB38WpKGlfM4ah8neGp1+DqgvCLeg=:G3vqUawVLeLV1mZCS2YXSMG6kbhyZOeP9K8NmrvBMVo=';

--
-- User Configurations
--








\unrestrict 6lYML2hH8NexFCid87JrJFxdjiyzfIm6XqmvDRTYP8mVadrwXSbIkk8CieVpGPe

--
-- PostgreSQL database cluster dump complete
--

